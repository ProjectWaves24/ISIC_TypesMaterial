
% This program reads 2D ISIC data from dicom files
%and  creates   2D data for AFEM
% with different mesh sizes (h, 2h, 4h, 8h)
% Data files   can be obtained from
% https://challenge2020.isic-archive.com/

clear
close all

for iter = 1 : 1
	matFileName = sprintf('ISIC%d.dcm', iter);

% first image
%info = dicominfo('ISIC1.dcm');
info = dicominfo(matFileName);

Y = dicomread(info);
figure
imshow(Y,[]);
  saveas(gcf,'ISIC%d.png');


count = 0;
inew = 0;
jnew = 0;

nx = size(Y,1);  %  n_x-  nr.of points in x direction
ny =  size(Y,2); %  n_y - nr.of points in y direction
nz = 1;          %  n_z - nr.of points in z direction

% sort the data of Y into the mesh-grid
 Z = zeros(nx,ny);

% mesh sizes for the domain [0,1] x[0,1]
hx = 1/(nx-1);
hy = 1/(ny-1);


 for k=1:nz
 for j=1:ny
 for i=1:nx
     
 % for inp file to make computations on the twice bigger mesh
     if rem(i,10) == 0 && rem(j,10) == 0
%	  count = count +1;
%          inew  = inew +1;
%          jnew  = jnew +1;

% for visualization in MATLAB
     Z(inew,jnew) = Y(i+nx*((j-1) + ny*(k-1)));
% for working with C++/PETSC
     ISIC10h(count,1) =  Y(i+nx*((j-1) + ny*(k-1)));
       end
       
    end           
  end
end

% outFileName = sprintf('Zarray%d.dat', iter);
%save('Zarray.dat','Z','-ascii');

%write data with mesh size 10h
save(outFileName,'ISIC10h.dat','-ascii');

  
%% plotting

hx_new =  10*hx;
hy_new =  10*hy;

x1=0:hx_new:1;
y1=0:hy_new:1;
 
%plot original  sampled image 
subplot(1, 2, 1)

 figure 
h = surf(y1,x1,Z)
 colormap default
set(h,'edgecolor','none') 
colorbar

  %view(2)
 subplot(1, 2, 2) 
h = surf(y1,x1,Z)
view(2)
  colorbar
%colormap winter
colormap default

set(h,'edgecolor','none')

%shading interp

 

  

end
