
% This program reads 2D ISIC data from dicom files
%and  creates sampled  2D data for AFEM
% with mesh size 100 time smaller than original.

% Data files   can be obtained from
% https://challenge2020.isic-archive.com/
% Size of original data: 4000 X 6000

clear
close all

for iter = 1 : 15
	matFileName = sprintf('ISIC%d.dcm', iter);

% first image
%info = dicominfo('ISIC1.dcm');
info = dicominfo(matFileName);

Y = dicomread(info);
figure
imshow(Y,[]);
  saveas(gcf,'ISIC%d.png');


count = 0;
inew = 0;
jnew = 0;

nx = size(Y,1);  %  n_x-  nr.of points in x direction
ny =  size(Y,2); %  n_y - nr.of points in y direction
nz = 1;          %  n_z - nr.of points in z direction

% resize image to do it smaller
nx_new = nx/100;
ny_new = ny/100;

% sort the data of Y into the mesh-grid
 Z = zeros(nx_new,ny_new);

% mesh sizes for the domain [0,1] x[0,1]
hx = 1/(nx-1);
hy = 1/(ny-1);


 for k=1:nz
 for j=1:ny
 for i=1:nx
     
 % for inp file to make computations on the twice bigger mesh
     if rem(i,100) == 0 && rem(j,100) == 0
	  count = count +1;

% for working with C++/PETSC
     ISIC100h(count,1) =  Y(i+nx*((j-1) + ny*(k-1)));
       end
       
    end           
  end
end
%**********************************************
% outFileName = sprintf('ISIC100h%d.dat', iter);
%save('Zarray.dat','Z','-ascii');

%write data with mesh size 100h
%save(outFileName,'ISIC100h','-ascii');


%% plotting of sampled data

hx_new =  100*hx;
hy_new =  100*hy;

x1=0:hx_new:1;
y1=0:hy_new:1;

% sort the data of Y into the mesh-grid
 Z = zeros(nx_new,ny_new);

nz =1;
  
  for jj=1:ny_new
  for ii=1:nx_new
 % for Matlab's visualization
	%	globnr = ii+nx_new*((jj-1) + ny_new*(kk-1));
        globnr = ii+nx_new*(jj-1);
   Z(ii,jj) = ISIC100h(globnr);

end
end



  
%% plotting

hx_new =  100*hx;
hy_new =  100*hy;

x1=0:hx_new:1;
y1=0:hy_new:1;

figure
%plot original  sampled image 
subplot(1, 2, 1)

 
h = surf(y1,x1,Z)
 colormap default
set(h,'edgecolor','none') 
colorbar

  %view(2)
 subplot(1, 2, 2) 
h = surf(y1,x1,Z)
view(2)
  colorbar
%colormap winter
colormap default

set(h,'edgecolor','none')

%shading interp



end
