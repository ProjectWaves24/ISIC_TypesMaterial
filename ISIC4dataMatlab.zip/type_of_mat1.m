
% This program reads 2D ISIC data from dicom files
%and  creates sampled  2D data for AFEM
% with new mesh size which is 100 times smaller than original mesh.
% Data files   can be obtained from
% https://challenge2020.isic-archive.com/
% Original size:  4000 X 6000
%  Sampled size: 40 X 60

clear
close all

for iter = 1 : 1
	matFileName = sprintf('ISIC%d.dcm', iter);

% first image
%info = dicominfo('ISIC1.dcm');
info = dicominfo(matFileName);

Y = dicomread(info);
figure
imshow(Y,[]);
  saveas(gcf,'ISIC1.png');


count = 0;
inew = 0;
jnew = 0;

nx = size(Y,1);  %  n_x-  nr.of points in x direction
ny =  size(Y,2); %  n_y - nr.of points in y direction
nz = 1;          %  n_z - nr.of points in z direction

% resize image to do it smaller
nx_new = nx/100;
ny_new = ny/100;

% sort the data of Y into the mesh-grid
 Z = zeros(nx_new,ny_new);

% mesh sizes for the domain [0,1] x[0,1]
%hx = 1/(nx-1);
%hy = 1/(ny-1);

hx = 1;
hy = 1;

 for k=1:nz
 for j=1:ny
 for i=1:nx
     
 % for inp file to make computations on the twice bigger mesh
     if rem(i,100) == 0 && rem(j,100) == 0
	  count = count +1;

% for working with C++/PETSC
     ISIC100h(count,1) =  Y(i+nx*((j-1) + ny*(k-1)));

     Mtype = ISIC100h(count,1);
      [typemat,epsilon,sigma] = Compute_typemat(Mtype);
       ISICmat(count,1) =  typemat; 
       ISICeps(count,1) =  epsilon/5.0; 
       ISICsigma(count,1) = sigma/5.0; 

       end
       
    end           
  end

 outFileName = sprintf('ISICmat%d.dat', iter);
%write   data  for type of material  with mesh size 100h
save(outFileName,'ISICmat','-ascii');

 outFileName = sprintf('ISICeps%d.dat', iter);
%write   data  for epsilon  with mesh size 100h
save(outFileName,'ISICeps','-ascii');


 outFileName = sprintf('ISICsigma%d.dat', iter);
%write   data  for sigma  with mesh size 100h
save(outFileName,'ISICsigma','-ascii');

       
end
%**********************************************
 



%% plotting of sampled data

hx_new =  100*hx;
hy_new =  100*hy;

x1=0:hx_new:hx*nx-1;
y1=0:hy_new:hy*ny-1;

% sort the data of Y into the mesh-grid
 Z = zeros(nx_new,ny_new);
Ztype = zeros(nx_new,ny_new);
Zeps = zeros(nx_new,ny_new);
Zsigma = zeros(nx_new,ny_new);

nz =1;
  
  for jj=1:ny_new
  for ii=1:nx_new
 % for Matlab's visualization
	%	globnr = ii+nx_new*((jj-1) + ny_new*(kk-1));
        globnr = ii+nx_new*(jj-1);
   Z(ii,jj) = ISIC100h(globnr);
   Ztype(ii,jj) = ISICmat(globnr);
   Zeps(ii,jj) = ISICeps(globnr);
   Zsigma(ii,jj) = ISICsigma(globnr);

end
end
 

end

%*************** plotting data from sampled dcm image ***************
figure
%plot original  sampled image 
subplot(1, 2, 1)

h = surf(y1,x1,Z)
 colormap default
set(h,'edgecolor','none') 
colorbar

  %view(2)
 subplot(1, 2, 2) 
h = surf(y1,x1,Z)
view(2)
  colorbar
%colormap winter
colormap default

set(h,'edgecolor','none')

%shading interp

  saveas(gcf,'ISICsampled.png');

  %___________________________________plotting type of material 
  figure
%plot original  sampled image 
subplot(1, 2, 1)

h = surf(y1,x1,Ztype)
 colormap default
set(h,'edgecolor','none') 
colorbar

  %view(2)
 subplot(1, 2, 2) 
h = surf(y1,x1,Ztype)
view(2)
  colorbar
%colormap winter
colormap default

set(h,'edgecolor','none')

%shading interp

  saveas(gcf,'ISICtypemat.png');

  %______________________________________________________________________

figure
%plot original  sampled image 
subplot(1, 2, 1)

h = surf(y1,x1,Zeps)
 colormap default
set(h,'edgecolor','none') 
colorbar

  %view(2)
 subplot(1, 2, 2) 
h = surf(y1,x1,Zeps)

view(2)
title('\epsilon_r')
  colorbar
%colormap winter
colormap default

set(h,'edgecolor','none')
title('\epsilon_r')
%shading interp

  saveas(gcf,'ISICeps.png');

  %---------------------------------------------------

figure
%plot original  sampled image 
subplot(1, 2, 1)

h = surf(y1,x1,Zsigma)
 colormap default
set(h,'edgecolor','none') 
colorbar
title('\sigma')
  %view(2)
 subplot(1, 2, 2) 
h = surf(y1,x1,Zsigma)
view(2)
colorbar
%colormap winter
colormap default

title('\sigma')

set(h,'edgecolor','none')

%shading interp

  saveas(gcf,'ISICsigma.png');

%__________________________________________________________________________
  %  function for determination of type of material for  ISIC bild 

  function [typemat,epsilon,sigma] =  Compute_typemat(Mtype)
  
 % transitional
  if (Mtype  <= 100 )
    typemat = 5;
    epsilon = 36;
    sigma = 3.5;
  end

  %  dry skin: typemat = 1
  if (Mtype > 200)
      typemat = 1;
    epsilon = 35;
    sigma = 3;

  end
  %  dry skin: typemat = 4
  if (Mtype > 100 && Mtype <= 160)
      typemat = 4;
       epsilon = 34 ;
       sigma = 3.0;
  end

    %  dry skin: typmat = 3
  if (Mtype > 160 && Mtype <= 180)
      typemat = 3;
       epsilon = 32;
       sigma = 2.5;
  end

      %  dry skin: typmat =2
  if (Mtype > 180 && Mtype <= 200)
      typemat = 2;
      epsilon = 32;
      sigma = 2.5;
  end

	      end

